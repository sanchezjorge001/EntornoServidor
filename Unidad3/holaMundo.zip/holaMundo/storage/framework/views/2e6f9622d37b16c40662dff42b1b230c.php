

<?php $__env->startSection('titulo', 'Página de Inicio'); ?>

<?php $__env->startSection('contenido'); ?>
    <h1>Bienvenido a Laravel</h1>
    <p>Esta es la página de inicio de mi aplicación.</p>
<?php $__env->stopSection(); ?>


<?php if($edad<18): ?>
    <p>Es menor</p>
<?php else: ?>
    <p>Es mayor</p>
<?php endif; ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\jorge\Desktop\2DAW\Jorge\Servidor\EntornoServidor\Unidad3\holaMundo\resources\views/inicio.blade.php ENDPATH**/ ?>