<h1 style="color: <?php echo e($color); ?>">
    <?php echo e($slot); ?>

</h1><?php /**PATH C:\Users\jorge\Desktop\2DAW\Jorge\Servidor\EntornoServidor\Unidad3\holaMundo\resources\views/components/color.blade.php ENDPATH**/ ?>