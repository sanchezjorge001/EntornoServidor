

<?php $__env->startSection('titulo', 'Hola Mundo'); ?>

<?php $__env->startSection('contenido'); ?>
    <?php if($edad<18): ?>
        <?php if (isset($component)) { $__componentOriginal147e118bc35dd90a45b298940398ace6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal147e118bc35dd90a45b298940398ace6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.color','data' => ['color' => 'red']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('color'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['color' => 'red']); ?>Es menor <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal147e118bc35dd90a45b298940398ace6)): ?>
<?php $attributes = $__attributesOriginal147e118bc35dd90a45b298940398ace6; ?>
<?php unset($__attributesOriginal147e118bc35dd90a45b298940398ace6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal147e118bc35dd90a45b298940398ace6)): ?>
<?php $component = $__componentOriginal147e118bc35dd90a45b298940398ace6; ?>
<?php unset($__componentOriginal147e118bc35dd90a45b298940398ace6); ?>
<?php endif; ?>
    <?php else: ?>
        <?php if (isset($component)) { $__componentOriginal147e118bc35dd90a45b298940398ace6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal147e118bc35dd90a45b298940398ace6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.color','data' => ['color' => 'green']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('color'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['color' => 'green']); ?>Es mayor <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal147e118bc35dd90a45b298940398ace6)): ?>
<?php $attributes = $__attributesOriginal147e118bc35dd90a45b298940398ace6; ?>
<?php unset($__attributesOriginal147e118bc35dd90a45b298940398ace6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal147e118bc35dd90a45b298940398ace6)): ?>
<?php $component = $__componentOriginal147e118bc35dd90a45b298940398ace6; ?>
<?php unset($__componentOriginal147e118bc35dd90a45b298940398ace6); ?>
<?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\jorge\Desktop\2DAW\Jorge\Servidor\EntornoServidor\Unidad3\holaMundo\resources\views/edad.blade.php ENDPATH**/ ?>