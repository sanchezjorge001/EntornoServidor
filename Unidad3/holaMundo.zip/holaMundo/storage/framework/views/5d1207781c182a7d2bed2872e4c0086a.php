<!DOCTYPE html>
<html>
<head>
    <title><?php echo $__env->yieldContent('titulo'); ?></title>
</head>
<body>
    <header>
        <?php echo $__env->make('plantillas.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </header>
    <main>
        <?php echo $__env->yieldContent('contenido'); ?>
    </main>
</body>
</html><?php /**PATH C:\Users\jorge\Desktop\2DAW\Jorge\Servidor\EntornoServidor\Unidad3\holaMundo\resources\views/layout.blade.php ENDPATH**/ ?>