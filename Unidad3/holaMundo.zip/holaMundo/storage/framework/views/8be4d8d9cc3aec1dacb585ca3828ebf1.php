<nav>
    <ul>
        <li><a href="/hola">Hola</a></li>
        <li><a href="/edad">Edad</a></li>
    </ul>
</nav><?php /**PATH C:\Users\jorge\Desktop\2DAW\Jorge\Servidor\EntornoServidor\Unidad3\holaMundo\resources\views/plantillas/navbar.blade.php ENDPATH**/ ?>