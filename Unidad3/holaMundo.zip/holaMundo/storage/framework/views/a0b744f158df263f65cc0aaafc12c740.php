

<?php $__env->startSection('titulo', 'Lista de numeros'); ?>

<?php $__env->startSection('contenido'); ?>
    <h2>Lista de numeros del 1 al <?php echo e($size); ?></h2>
    <ul>
        <?php $__currentLoopData = $numeros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $numero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($numero); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\jorge\Desktop\2DAW\Jorge\Servidor\EntornoServidor\Unidad3\holaMundo\resources\views/numeros.blade.php ENDPATH**/ ?>