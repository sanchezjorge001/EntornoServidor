<h1 style="color: {{ $color }}">
    {{ $slot }}
</h1>