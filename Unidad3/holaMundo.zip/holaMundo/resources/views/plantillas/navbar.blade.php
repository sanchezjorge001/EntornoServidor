<nav>
    <ul>
        <li><a href="/hola">Hola</a></li>
        <li><a href="/edad">Edad</a></li>
    </ul>
</nav>