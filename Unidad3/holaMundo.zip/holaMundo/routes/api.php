<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Calculadora;

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');


Route::get('/hola/{nombre?}', function ($nombre = 'Mundo') {
    return response()->json([
        'mensaje' => "Hola, $nombre!",
    ]);
});


Route::get('/sumar/{n1?}/{n2?}', [Calculadora::class, 'sumar']);

Route::get('/numeros/{size}', [Calculadora::class, 'listaNumeros']);
